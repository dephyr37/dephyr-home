# The building blocks

A Pen created on CodePen.io. Original URL: [https://codepen.io/oarnadmin/pen/NWeMZyo](https://codepen.io/oarnadmin/pen/NWeMZyo).

Inspiration from fluent.microsoft.com. The shadows adapt to the cube state. Click the cube to toggle rotation. Click the buttons to toggle collapsing and expanding. Tested with Chrome, Safari on Mac, and Chrome on Android.